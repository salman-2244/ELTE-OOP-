#include <iostream>
#include <vector>
#include <fstream>
#include <sstream> /** for reading input of varying length*/

using namespace std;

const int small = 10;
const int medium = 15;
const int large = 20;

struct Pizza
{
    string name;
    string size;
    vector<string> extra_wishes;
    friend istream &operator>>(istream &is,Pizza &pizza);
    friend ostream &operator<<(ostream &os,const Pizza &pizza);
};

istream &operator >>(istream &is,Pizza &p)
{
    is >> p.name >> p.size;
    p.extra_wishes.clear();
    string order;
    while (is >> order)
    {
        p.extra_wishes.push_back(order);
    }
    return is;
}

ostream &operator<<(ostream &os,const Pizza &p)
{
    os << p.name << " " << p.size <<" ";
    for(unsigned int i=0;i<p.extra_wishes.size();i++)
    {
        os<< p.extra_wishes[i] << " ";
    }
    os<<'\n';
    return os;
}

struct Order
{
    string customer_name;
    Pizza pizza_order;
    int Total() const;
    friend istream &operator>>(istream &is,Order &order);
    friend ostream &operator<<(ostream &os,const Order &order);
};

int Order::Total() const
{
    int sum = 0;
    cout<< pizza_order <<endl;
    if(pizza_order.size == "small")
    {
        sum += small;
    }
    else if(pizza_order.size == "medium")
    {
        sum+= medium;
    }
    else if(pizza_order.size == "large")
    {
        sum+= large;
    }
    if(pizza_order.extra_wishes.size() != 0)
    {
        sum+= pizza_order.extra_wishes.size();
    }
    return sum;
}

ostream &operator<<(ostream &os,const Order &order)
{
    os << order.customer_name << " " << order.pizza_order;

    return os;
}

istream &operator>>(istream &is,Order &order) /// variable is has to be a stringstream
{
    is >> order.customer_name;
    is >> order.pizza_order;
    return is;
}

enum Status{norm,abnorm};

void open (ifstream &f); /// safe opening

template <typename Item>
void read(Status &st,Item &e, ifstream &f); /// reading operation for any type of data (template)

int calcTotal(ifstream &f); /// result calculation

int main()
{
    ifstream f;
    open(f);
    cout << "\nToday's income: " << calcTotal(f) << " EUR.\n";
    f.close();
    return 0;
}

void open(ifstream &f) /// safe opening
{
    do
    {
        cout << "File's name: ";
        string fname; /// = "data.txt";
        cin >> fname;
        f.open(fname.c_str());
    } while (f.fail());
}

template <typename Item>
void read(Status &st,Item &e,ifstream &f)
{
    string line;
    getline(f,line,'\n'); /// there is only one order's data in variable line
    if (f.fail() || line == "")
    {
        st = abnorm;
    }
    else
    {
        st = norm;
        stringstream ss(line); /// only one order
        ss >> e;
        ss.clear();
    }
}

int calcTotal(ifstream &f)
{
    int s = 0;
    Status st;
    Order e;
    ///t.first
    read<Order>(st,e,f); ///using template with concrete datatype: Item = Order

    //cout<< pizza_order;
    while (st==norm) ///!t.end
    {
        s += e.Total();/// s = s+...
        read<Order>(st,e,f); ///next
    }
    return s;
}
