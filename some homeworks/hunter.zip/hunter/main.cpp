#include "enor.h"

/**
In a sequential input file, hunt trophies are stored: hunter name, species, weight.
*/

/// HW: On average, how many preys have the hunters shot? In case of empty file, the average is zero!

using namespace std;

int main()
{
    try
    {
        Enor t("inp.txt");
        int hunters=0 ;
        int total_preys=0;
        for(t.first(); !t.end(); t.next()){ ++hunters;}
        cout << "The number of preys: " << t.total_preys()<< " " << endl;
        cout << "The number of hunters: " << hunters<< " " << endl;
        float average = (float)t.total_preys()/(float)hunters;
        if(hunters==0)
        {
            cout << "The average preys/hunters is: 0" << endl;
        }
        else{
            cout << "The average preys/hunters is: " << average << endl;
        }
    }
    catch (Enor::Errors exp)
    {
        cout << "Wrong file name!\n";
        return 1;
    }
    return 0;
}
