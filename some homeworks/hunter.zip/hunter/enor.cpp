#include "enor.h"

std::istream &operator>>(std::istream &is,Prey &p)
{
    is >> p.name >> p.spec >> p.weight;
    return is;
}

Enor::Enor(const std::string &fileName)
{
    _x.open(fileName.c_str());
    if(_x.fail()) throw FILEERROR;
}

void Enor::next()
{
    _end = (abnorm == _sx);
    if (!_end) {
    ///if ( !(_end = (abnorm == _sx)) ){
        std::string name = _dx.name;
        while (norm == _sx && _dx.name == name)
        {
            preys++;
            read();
        }
        /**for( ; norm == _sx && _dx.name == name; read() ){
            _cur = _cur || ("rabbit" == _dx.spec);
        }*/
    }
}


void Enor::read()
{
    _x >> _dx;
    _sx = _x.fail() ? abnorm : norm;
    /// if (_x.fail()) { _sx = abnorm; } else { _sx = norm; }
}
