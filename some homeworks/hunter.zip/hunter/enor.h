#pragma once

#include <string>
#include <iostream>
#include <fstream>

enum Status { abnorm, norm };

struct Prey {
    std::string name;
    std::string spec;
    int weight;
    friend std::istream &operator>>(std::istream &is,Prey &p);
};

class Enor
{
    public:

        enum Errors { FILEERROR };
        Enor(const std::string &fileName);
        ~Enor() { _x.close(); }
        void first() { read(); next(); }
        void next();
        int total_preys() { return preys;}
        bool end() const { return _end; }
    private:
        std::ifstream _x;
        Prey _dx;
        Status _sx;
        int preys = 0;
        bool _end;
        void read(); /// sx, dx, x : read
};


