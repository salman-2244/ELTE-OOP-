#ifndef MOODOFCATHY_H
#define MOODOFCATHY_H

#include <iostream>
#include <string>

class Dog;
class Fish;
class Bird;


class Mood
{
public:
    virtual Mood* modifyMood(Dog *p) = 0;
    virtual Mood* modifyMood(Bird *p) = 0;
    virtual Mood* modifyMood(Fish *p) = 0;
    virtual Mood* increase() = 0;
};

class Ordinary : public Mood
{
public:
    static Ordinary* instance();
    Mood* modifyMood(Dog *p) override;
    Mood* modifyMood(Bird *p) override;
    Mood* modifyMood(Fish *p) override;
    Mood* increase() override;
    static void destroy();

protected:
    Ordinary(){}
private:
    static Ordinary* _instance;

};


class Bad : public Mood
{
public:
    static Bad* instance();
    Mood* modifyMood(Fish *p) override;
    Mood* modifyMood(Dog *p) override;
    Mood* modifyMood(Bird *p) override;
    Mood* increase() override;
    static void destroy();
protected:
    Bad(){}
private:
    static Bad* _instance;


};

class Good : public Mood
{
public:
    static Good* instance();
    Mood* modifyMood(Dog *p) override;
    Mood* modifyMood(Bird *p) override;
    Mood* modifyMood(Fish *p) override;
    Mood* increase() override;
    static void destroy();
protected:
    Good(){}
private:
    static Good* _instance;

};


#endif // MOODOFCATHY_H
